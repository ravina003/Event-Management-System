package com.project.model;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String qrCodeUrl; // URL for the QR code
    private String paymentStatus; // e.g., PENDING, SUCCESS, FAILED
    private LocalDateTime paymentDate; // Date and time of payment
    private double amount; // Amount paid
	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Payment(Long id, String qrCodeUrl, String paymentStatus, LocalDateTime paymentDate, double amount) {
		super();
		this.id = id;
		this.qrCodeUrl = qrCodeUrl;
		this.paymentStatus = paymentStatus;
		this.paymentDate = paymentDate;
		this.amount = amount;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getQrCodeUrl() {
		return qrCodeUrl;
	}
	public void setQrCodeUrl(String qrCodeUrl) {
		this.qrCodeUrl = qrCodeUrl;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public LocalDateTime getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(LocalDateTime paymentDate) {
		this.paymentDate = paymentDate;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Payment [id=" + id + ", qrCodeUrl=" + qrCodeUrl + ", paymentStatus=" + paymentStatus + ", paymentDate="
				+ paymentDate + ", amount=" + amount + "]";
	}
}
