package com.project.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.project.model.Admin;
import com.project.model.Event;
import com.project.model.Payment;
import com.project.repository.AdminRepo;
import com.project.repository.EventRepository;
import com.project.repository.PaymentRepository;

@Controller
public class AdminController {

	@Autowired
	AdminRepo arepo;
	
	@Autowired
    EventRepository eventRepository;

	
	  @Autowired
	    PaymentRepository paymentRepository;

	    // Existing methods...

	  @RequestMapping("/")
		public String home()
		{
			  return "mainhomepage";
		}
	   
//	@RequestMapping("/signup")
//	public String sign()
//	{
//		  return "adminlogin";
//	}
	@RequestMapping("/signup")
	public String login()
	{
		//arepo.save(ob);
		  return "adminlogin";
	}
	
	@RequestMapping("/addevent")
	public String login1(@RequestParam String email,@RequestParam  String password)
	{
		Admin ob=arepo.findByEmail(email);
		if(ob!=null && ob.getEmail().equalsIgnoreCase(email) && ob.getPassword().equals(password))
		{
			return "admindashboard";
		}
		else
		{
			 String msg = "Incorrect Email or Password!!!";
			return "adminlogin.jsp?message="+msg;
		}
	}
	
	
	
    @GetMapping("/add")
    public String showAddEventForm(Model model) {
        model.addAttribute("event", new Event());
        return "addEvent";
    }

    @PostMapping("/add")
    public String addEvent(Event event, @RequestParam("image") MultipartFile image) {
        if (!image.isEmpty()) {
            try {
                // Get the absolute path for the uploads directory
                String uploadsDir = System.getProperty("user.dir") + "/uploads/images/";
                File uploadDir = new File(uploadsDir);
                
                // Create the directory if it doesn't exist
                if (!uploadDir.exists()) {
                    boolean created = uploadDir.mkdirs(); // This creates the directory structure
                    if (!created) {
                        throw new IOException("Failed to create directory: " + uploadsDir);
                    }
                }
                
                // Define the path where the image will be saved
                String imagePath = uploadsDir + image.getOriginalFilename();
                image.transferTo(new File(imagePath));
                event.setImageUrl("/uploads/images/" + image.getOriginalFilename()); // Serve from a base path

            } catch (IOException e) {
                e.printStackTrace();
                return "error"; // Return to an error page if needed
            }
        }
        eventRepository.save(event);
        return "redirect:/add"; // Redirect to the form after saving
    }
    
    @GetMapping("/events")
    public String listEvents(Model model) {
        List<Event> events = eventRepository.findAll();
        model.addAttribute("events", events);
        return "eventList"; // This should return the eventList.jsp page
    }
    
    @GetMapping("{id}")
    public String showEditEventForm(@PathVariable Long id, Model model) {
        Event event = eventRepository.findById(id).orElseThrow(() -> new RuntimeException("Event not found"));
        model.addAttribute("event", event);
        return "editEvent"; // This should return the editEvent.jsp page
    }

    @PostMapping("{id}")
    public String updateEvent(@PathVariable Long id, Event event, @RequestParam("image") MultipartFile image) {
        Event existingEvent = eventRepository.findById(id).orElseThrow(() -> new RuntimeException("Event not found"));
        
        existingEvent.setName(event.getName());
        existingEvent.setDate(event.getDate());
        existingEvent.setLocation(event.getLocation());

        // Handle image upload
        if (!image.isEmpty()) {
            try {
                String uploadsDir = System.getProperty("user.dir") + "/uploads/images/";
                String imagePath = uploadsDir + image.getOriginalFilename();
                image.transferTo(new File(imagePath));
                existingEvent.setImageUrl("/uploads/images/" + image.getOriginalFilename());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        eventRepository.save(existingEvent);
        return "redirect:/events"; // Redirect to the event list after updating
    }

    
    @GetMapping("/delete/{id}")
    public String deleteEvent(@PathVariable Long id) {
        eventRepository.deleteById(id);
        return "redirect:/events"; // Redirect to the event list after deleting
    }

    @GetMapping("/viewPayments")
    public String viewPayments(Model model) {
        List<Payment> payments = paymentRepository.findAll();
        model.addAttribute("payments", payments);
        return "ViewPaymentDetails"; // Render the view payments page
    }
    @RequestMapping("/alogout")
    public String logout()
    {
    	return "mainhomepage";
    }
	
    @GetMapping("/delete1/{id}")
    public String deletePayment(@PathVariable Long id) {
        paymentRepository.deleteById(id);
        return "redirect:/viewPayments"; // Redirect to the event list after deleting
    }


}
