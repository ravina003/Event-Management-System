package com.project.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import com.project.model.Event;
import com.project.model.Payment;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.model.User;
import com.project.repository.EventRepository;
import com.project.repository.PaymentRepository;
import com.project.repository.UserRepo;

@Controller
public class UserController 
{
	@Autowired
	UserRepo urepo;
	
	@Autowired
    EventRepository eventRepository;

	 @Autowired
	 PaymentRepository paymentRepository;
	
	@RequestMapping("/signup12")
	public String ulogin(@ModelAttribute User ob)
	{
		  urepo.save(ob);
		  return "UserSignUp";
	}
	
	@GetMapping("/events1")
	public String listUserEvents(Model model) 
	{
	    List<Event> events = eventRepository.findAll(); // Ensure this line is correct
	    model.addAttribute("events", events); // Add events to the model
	    return "UserViewEventList";
	}
	
	 @RequestMapping("/details/{id}")
	    public String getEventDetails12(@PathVariable Long id, Model model) {
	        Event event = eventRepository.findById(id)
	            .orElseThrow(() -> new RuntimeException("Event not found")); // Handle event not found
	  
	        model.addAttribute("event", event); // Add event to the model
	        return "eventDetails"; // Return the JSP page name to render
	    }
	 
	
	 @RequestMapping("/bookEvent")
	    public String bookEvent() 
	 {     
		 return "paymentForm";
	 }
	 
	    @PostMapping("/processPayment")
	    public String processPayment(@RequestParam double amount, Model model) {
	        // Generate a payment link and QR code
	        String paymentLink = "https://paymentgateway.com/pay?amount=" + amount;
	        String qrCodeUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" + paymentLink + "&size=150x150";

	        // Create a new Payment object
	        Payment payment = new Payment();
	        payment.setQrCodeUrl(qrCodeUrl);
	        payment.setPaymentStatus("PENDING");
	        payment.setPaymentDate(LocalDateTime.now());
	        payment.setAmount(amount);

	        // Save payment details
	        paymentRepository.save(payment);

	        model.addAttribute("paymentInfo", payment);
	        return "paymentPage"; // Render the payment page with QR code
	    }
	    
	    @PostMapping("/confirmPayment")
	    public String confirmPayment(@RequestParam Long paymentId, Model model) {
	        Payment payment = paymentRepository.findById(paymentId).orElse(null);
	        if (payment != null) {
	            // Simulate a payment confirmation process
	            String[] statuses = {"SUCCESS", "FAILED"};
	            String randomStatus = statuses[new Random().nextInt(statuses.length)];
	            payment.setPaymentStatus(randomStatus);
	            paymentRepository.save(payment); // Update payment status

	            model.addAttribute("paymentInfo", payment);
	        } else {
	            model.addAttribute("error", "Payment not found");
	        }
	        return "paymentPage"; // Render the payment page with updated status
	    }
 
	@RequestMapping("/Success")
	public String succes()
	{
		  return "success";
	}
	
	
}
